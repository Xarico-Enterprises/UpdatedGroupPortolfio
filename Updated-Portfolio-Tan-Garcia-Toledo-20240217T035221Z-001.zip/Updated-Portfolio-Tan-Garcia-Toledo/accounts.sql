CREATE DATABASE accounts;
USE accounts;
CREATE TABLE tbl_acc (
    id INT NOT NULL AUTO_INCREMENT,
    username VARCHAR(255),
    password VARCHAR(255),
    PRIMARY KEY (id)
);

insert into tbl_acc (username,password) values ('Xaki','CeasarSalad');
insert into tbl_acc (username,password) values ('Ceptolotl','WilliamAff');
insert into tbl_acc (username,password) values ('Snuffkin','Snuffkinowo');