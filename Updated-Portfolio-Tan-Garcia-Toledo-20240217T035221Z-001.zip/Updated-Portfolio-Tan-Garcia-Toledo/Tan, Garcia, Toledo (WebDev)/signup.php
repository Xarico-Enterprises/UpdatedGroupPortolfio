<?php
session_start();
include("database.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  //grabs the input's username and password to php
    $username = $_POST["username"];
    $password = $_POST["password"];

    $stmt = $conn->prepare("INSERT INTO tbl_acc (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->close();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>replit</title>
  <link rel="stylesheet" href="signup.css">
</head>
<body>
<!--signup form -->
  <div class="signup">
    <form id="signInForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <h2>Sign up!!</h2>
      <label for="name">Username:</label>
      <input type="text" id="username" name="username" placeholder="Username Here.." required>
      
      <div class="formtext">
        <label for="color">Password:</label>
        <input type="password" id="password" name="password" placeholder="Password Here.." required>
      </div>
      
      <div class="formtext">
        <label for="gradelevel">Grade Level:</label>
        <input type="number" id="gradelevel" name="gradelevel" placeholder="Grade Here..">
      </div>
      
      <div class="formtext">
        <label for="color">Favorite Color:</label>
        <input type="text" id="favcolor" name="favcolor" placeholder="Color Here..">
      </div>
      
      <div class="formtext">
        <label for="food">Favorite Food:</label>
        <input type="text" id="favfood" name="favfood" placeholder="Food Here..">
      </div>
      
      <div class="formtext">
          <button class="button" type="submit">Sign up</button>
      </div>
    </form>
  </div>
  <br>
  <br>
</body>
</html>
