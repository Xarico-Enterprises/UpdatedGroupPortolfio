var users = [
  {
    username: 'Snuffkin', password: 'Snuffkinowo'
  },
];

function validateForm2(){
  var usernameInput = document.getElementById('username').value;
  var passwordInput = document.getElementById('password').value;

  var isValidUser = false;
  for (var i = 0; i < users.length; i++){
    if (usernameInput == users[i].username && passwordInput == users[i].password){
      isValidUser = true;
      break;
    }
  }

  if (isValidUser) {
    alert('Hey hey thats nice!');
    window.location.href = 'jacobresumehome.html';
  }
  else {
    var errorMessage = document.getElementById('error-message');
    errorMessage.innerHTML = 'Invalid';
  }
}