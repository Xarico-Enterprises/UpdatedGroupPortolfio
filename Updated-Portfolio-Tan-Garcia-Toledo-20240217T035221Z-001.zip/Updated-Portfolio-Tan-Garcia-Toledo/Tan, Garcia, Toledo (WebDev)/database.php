<?php
$conn = mysqli_connect("localhost", "root", "admin123");

// Check connection
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

$db_selected = mysqli_select_db($conn, "accounts");

if (!$db_selected) {
    die("Could not select database: " . mysqli_error($conn));
}
?>