<?php
session_start();
//inheriting the connection code from database.php
include("database.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        $username = $_POST["username"];
        $password = $_POST["password"];

        $query = "SELECT * FROM tbl_acc WHERE username = '$username' AND password = '$password'";
        $result = mysqli_query($conn, $query);

        //authenticates the log in
        if ($result) {
            if (mysqli_num_rows($result) == 1) {
                $_SESSION["username"] = $username;
                $_SESSION["password"] = $password;
                header("Location: homepage.html");
                exit();
            } else {
                $error_message = "Invalid username or password.";
            }
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Username or password not provided.";
    }
}

mysqli_close($conn);
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Resume With Signup</title>
  <link href="login.css" rel="stylesheet" type="text/css" />
  <link href="index.html">
</head>

<body>
  <img class="background" src="geogif2.gif" alt="geotreeart">
  <div class="container" style="position: absolute;">
    <form id="loginForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
      <h2 class="logintxt">Login</h2>
      <label for="username">Username:</label>
      <input type="text" placeholder="Enter username" id="username" name="username" required>

      <label for="password">Password:</label>
      <input type="password" placeholder="Enter password" id="password" name="password" required>

      <button type="submit">Login</button>
    </form>
    <a class=signup href="signup.php">Sign up!</a>
    <div id="error-message"><?php if (isset($error_message)) echo $error_message; ?></div>
  </div>

</body>
</html>
